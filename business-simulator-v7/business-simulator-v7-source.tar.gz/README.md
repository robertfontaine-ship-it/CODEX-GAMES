# Business Optimization Simulator V7

V7 converts the portable V6 prototypes into a structured classroom platform.

## Working classroom loop

1. Teacher creates an account or enters browser demo mode.
2. Teacher creates a reusable campaign.
3. Teacher creates a classroom and receives a six-character join code.
4. Student joins with the class code, assigned ID, display name, and four-digit PIN.
5. Student launches a business, completes decisions, predicts results, runs the month, and reflects.
6. Draft decisions autosave.
7. Lesson submissions appear automatically in the teacher roster.
8. Teacher controls which lesson is currently open.

## Technology

- React + TypeScript
- Vite
- Supabase Auth for teachers
- Postgres + Row Level Security for teacher-owned data
- Pseudonymous student sessions through security-definer RPC functions
- Local browser demo adapter when Supabase variables are absent
- Vitest simulation-engine tests

## Local development

```bash
npm install
npm run dev
```

Without environment variables, the app launches in **Demo Mode**. Teacher and student workflows work in the same browser using local storage.

## Hosted backend setup

1. Create a Supabase project.
2. Run `supabase/migrations/202607150001_v7_classroom.sql` in the SQL editor or through the Supabase CLI.
3. Enable email/password authentication for teachers.
4. Copy `.env.example` to `.env.local` and add the project URL and publishable key.
5. Restart the development server.

```bash
cp .env.example .env.local
npm run dev
```

## Validation

```bash
npm run lint
npm test
npm run build
```

## Deployment

Build command:

```bash
npm run build
```

Publish directory:

```text
dist
```

`public/_redirects` provides SPA routing for hosts that support Netlify-style redirect rules. For other hosts, configure all application routes to fall back to `index.html`.

## Privacy model

- Teachers authenticate with email and password.
- Students do not provide email addresses.
- Student PINs are hashed with Postgres `pgcrypto` in hosted mode.
- Student browser access is performed through expiring opaque session tokens.
- Students cannot query database tables directly.
- Teachers can only read campaigns, classrooms, businesses, and submissions attached to their authenticated account.

## Current scope

This branch delivers the V7 Phase 1 and Phase 2 foundation:

- structured simulation engine
- teacher authentication
- campaign and class creation
- class codes
- pseudonymous cross-device student sign-in
- autosave
- automatic lesson submissions
- live teacher roster
- teacher lesson pacing

Next platform work should add teacher feedback, rubric scoring, CSV gradebook export, class-level diagnostic analytics, and deployment automation.
