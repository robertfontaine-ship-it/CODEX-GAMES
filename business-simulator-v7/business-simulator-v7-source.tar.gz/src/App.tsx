import { useEffect, useState } from 'react';
import { HomePage } from './pages/HomePage';
import { StudentPortal } from './pages/StudentPortal';
import { TeacherPortal } from './pages/TeacherPortal';
import { platform } from './services/platform';
import './index.css';

function normalizePath(pathname: string): string {
  if (pathname.startsWith('/teacher')) return '/teacher';
  if (pathname.startsWith('/student')) return '/student';
  return '/';
}

export default function App() {
  const [path, setPath] = useState(() => normalizePath(window.location.pathname));

  useEffect(() => {
    const handler = () => setPath(normalizePath(window.location.pathname));
    window.addEventListener('popstate', handler);
    return () => window.removeEventListener('popstate', handler);
  }, []);

  function navigate(nextPath: string) {
    window.history.pushState({}, '', nextPath);
    setPath(normalizePath(nextPath));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (path === '/teacher') return <TeacherPortal onNavigate={navigate} />;
  if (path === '/student') return <StudentPortal onNavigate={navigate} />;
  return <HomePage onNavigate={navigate} mode={platform.mode} />;
}
